# 博客

```
    https://www.simon96.online/2018/10/12/hexo-tutorial/
    https://github.com/cofess/hexo-theme-pure/blob/master/README.cn.md
    https://hexo.io/zh-cn/docs/commands
```